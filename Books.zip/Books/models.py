from django.db import models

# Create your models here.
class Contact(models.Model):
    name =models.CharField(max_length=20)
    email =models.EmailField(max_length=50)
    mess =models.CharField(max_length=1000)

    def __str__(self):
        return self.name

class Write(models.Model):
    name =models.CharField(max_length=20)
    email =models.EmailField(max_length=50)
    books_name=models.CharField(max_length=50)
    cat_name=models.CharField(max_length=50)
    image =models.ImageField(upload_to="Books/write_img/",default ="")
    desc =models.TextField()

    def __str__(self):
        return self.name     

class Join(models.Model):
    name =models.CharField(max_length=20)
    email =models.EmailField(max_length=50)
    password =models.CharField(max_length=1000)

    def __str__(self):
        return self.name    



class Library_Database(models.Model):
    books_name=models.CharField(max_length=50,default ="")
    cat_name=models.CharField(max_length=50,default ="")
    cat_image =models.ImageField(upload_to="Books/Library_Database/img/",default ="")
    cat_desc =models.TextField()

    def __str__(self):
        return self.books_name   

# cat_name is always in small letter and it is the way to serch data by cateogry


class Library_collection(models.Model):
    books_name=models.CharField(max_length=50,default ="")
    author_name=models.CharField(max_length=50,default ="")
    cat_name=models.CharField(max_length=50,default ="")
    image =models.ImageField(upload_to="Books/Library_Database/img/",default ="")
    file =models.FileField(upload_to="Books/Library_Database/file/",default ="")

    def __str__(self):
        return self.books_name   