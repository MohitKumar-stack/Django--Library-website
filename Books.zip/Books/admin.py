from django.contrib import admin
from .models import Contact,Write,Join,Library_Database,Library_collection
# Register your modeles here.
admin.site.register(Contact)
admin.site.register(Write)
admin.site.register(Join)
admin.site.register(Library_Database)
admin.site.register(Library_collection)