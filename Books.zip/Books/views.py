from django.shortcuts import render
from django.http import HttpResponse
from Books.models import Contact,Write,Join,Library_Database,Library_collection
from django.contrib import messages
from django.shortcuts import redirect

# notes ->  Library_collection,Library_Database cat_name is always same and small letter 
# Create your views here.

   
def index(request):
    library_Database=Library_Database.objects.all()
    return render(request,'Books\Index.html',{'Database':library_Database})

def Gallerypage(request,cat):
    library_Database=Library_Database.objects.all().filter(cat_name=cat)  
    library_list=Library_collection.objects.all().filter(cat_name=cat) 
    return render(request,'Books\Gallerypage.html',{'view_list':library_list,'headerDatabase': library_Database})    




def contact(request):
    if request.method=='POST':
        name =request.POST.get('name')
        email =request.POST.get('email')
        mess =request.POST.get('mess')
        contact=Contact(name=name,email=email,mess=mess)
        contact.save()
        messages.success(request, 'Your profile Save suvvessfully')
    return render(request,'Books\contact.html')




def write(request):
    if request.method=='POST':
        name =request.POST.get('name')
        email =request.POST.get('email')
        books_name =request.POST.get('books_name')
        cat_name =request.POST.get('cat_name')
        image=request.POST.get('image')
        desc =request.POST.get('desc')
        write=Write(name=name,email=email,books_name=books_name,cat_name=cat_name,image=image,desc=desc)
        write.save()
        messages.success(request, 'Your Request is send!')
    
    return render(request,'Books\write_on_us.html')
    




def about(request):
    if request.method=='POST':
        name =request.POST.get('name')
        email =request.POST.get('email')
        password =request.POST.get('password')
        join=Join(name=name,email=email,password=password)
        join.save()
        return redirect('/Home')
        messages.success(request, 'Your Request is send!')
       
    
    return render(request,'Books\About.html')




     